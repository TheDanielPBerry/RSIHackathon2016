﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HackathonRetroStoreWF
{
    public partial class Store : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddProduct_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AddProduct.aspx");
        }

        protected void ProductsGrid_ViewProduct(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewProduct")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                var prodId = ProductsGrid.DataKeys[index]["Id"].ToString();
                Response.Redirect(String.Format("ProductDetail.aspx?ProductId={0}", prodId));
            }
        }        
    }
}