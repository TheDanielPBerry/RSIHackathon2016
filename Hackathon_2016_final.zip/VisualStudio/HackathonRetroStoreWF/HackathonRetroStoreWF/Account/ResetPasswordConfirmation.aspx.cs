﻿using System.Web.UI;

namespace HackathonRetroStoreWF.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}