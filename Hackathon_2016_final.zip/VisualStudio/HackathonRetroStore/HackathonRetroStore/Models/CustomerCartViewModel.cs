﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace HackathonRetroStore.Models
{
    public class CustomerCartViewModel
    {
        public Customer Customer { get; set; }
        public List<Product> Products { get; set; }
        public List<int> Quantities { get; set; }
    }
}