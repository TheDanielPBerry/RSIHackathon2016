﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using HackathonRetroStore.Models;
using System.Text;
using System.Security.Cryptography;

namespace HackathonRetroStore.Services
{
    public class DBConnect
    {
        private string connectionString;
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataReader reader;

        #region DB Connection Methods
        // Obtain connection string to db from Web.config and store in global variable, and instantiate a SqlCommand
        public DBConnect()
        {
            connectionString = ConfigurationManager.ConnectionStrings["RetroStoreDev"].ConnectionString;
            command = new SqlCommand();
        }       

        // Connect to and query db, result data assigned to global variable reader if query is a SELECT. Else, INSERT/UPDATE executes. 
        private bool Query(string query, bool isExecuteNonQuery = false)
        {
            try
            {
                connection = new SqlConnection(connectionString);
                
                command.CommandText = query;
                command.CommandType = CommandType.Text;
                command.Connection = connection;

                connection.Open();

                if (isExecuteNonQuery)
                    command.ExecuteNonQuery();
                else
                    reader = command.ExecuteReader();
            }
            catch(Exception e)
            {                
                return false;
            }

            return true;
            
        }

        // Clear global connection properties for reuse
        private void CloseConnection()
        {
            connection.Close();
            command.Parameters.Clear();
            if (reader != null)
                reader.Close();            
        }
        #endregion

        #region Product Methods

        // Query product table for all data, iterate SQLDataReader result to map results to model objects, close connection and clear global vars
        public List<Product> GetAllProducts()
        {
            var tableName = "Product";
            var queryString = String.Format("SELECT * FROM {0}", tableName);
            Query(queryString);

            var productList = new List<Product>();
            Product product;

            try
            {
                while (reader.Read())
                {
                    product = new Product()
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = Convert.ToString(reader["Name"]),
                        Description = Convert.ToString(reader["Description"]),
                        QuantityInStock = Convert.ToInt32(reader["QuantityInStock"]),
                        Price = Convert.ToDecimal(reader["Price"]),
                        PictureFileName = Convert.ToString(reader["PictureFileName"])
                    };

                    productList.Add(product);
                }
            }
            catch
            {
                // Error Handler
            }

            CloseConnection();

            return productList;
        }

        // Add new Product to db (admin functionality)
        public bool SaveNewProduct(Product newProduct)
        {          
            var queryString = "INSERT INTO PRODUCT VALUES (@name, @description, @quantity, @price, @picture)";

            command.Parameters.AddWithValue("@name", newProduct.Name);
            command.Parameters.AddWithValue("@description", newProduct.Description);
            command.Parameters.AddWithValue("@quantity", (newProduct.QuantityInStock > 5 ? 0 : newProduct.QuantityInStock));
            command.Parameters.AddWithValue("@price", newProduct.Price);

            if(String.IsNullOrWhiteSpace(newProduct.PictureFileName))
                newProduct.PictureFileName =  "Default.png";

            command.Parameters.AddWithValue("@picture", newProduct.PictureFileName);

            var insertSuccess = Query(queryString, true);

            CloseConnection();

            return insertSuccess;
        }

        // Query for customer given Id, build Cart of pipe-delimited Product Ids, and update Customer's Cart in db
        public bool AddToCart(string customerName, int productId, int quantity)
        {
            var customer = GetCustomer(customerName);
            var customerCart = customer.Cart;

            if (String.IsNullOrWhiteSpace(customerCart))
                customerCart = Convert.ToString(productId);
            else
                customerCart += ("|" + Convert.ToString(productId) + "," + quantity);

            var queryString = "UPDATE CUSTOMER SET CART = @cart WHERE ID = @id";

            command.Parameters.AddWithValue("@cart", customerCart);
            command.Parameters.AddWithValue("@id", customerName);

            var updateSuccess = Query(queryString, true);

            CloseConnection();

            return updateSuccess;
        }
        #endregion

        #region Customer Methods

        public bool CreateCustomer(Customer customer)
        {            
            var queryString = "INSERT INTO CUSTOMER VALUES (@id, @firstName, @lastName, @street, @city, @state, @zip, @cart)";

            command.Parameters.AddWithValue("@id", customer.Id);
            command.Parameters.AddWithValue("@firstName", customer.FirstName);
            command.Parameters.AddWithValue("@lastName", customer.LastName);
            command.Parameters.AddWithValue("@street", customer.Street);
            command.Parameters.AddWithValue("@city", customer.City);
            command.Parameters.AddWithValue("@state", customer.State);
            command.Parameters.AddWithValue("@zip", customer.ZIP);
            command.Parameters.AddWithValue("@cart", customer.Cart);         

            var insertSuccess = Query(queryString, true);

            CloseConnection();

            return insertSuccess;
        }

        // Query for customer given Id, iterate query result in SQLDataReader to map to model object
        public Customer GetCustomer(string customerName)
        {
            var queryString = "SELECT * FROM CUSTOMER WHERE ID = @customerName";

            command.Parameters.AddWithValue("@customerName", customerName);

            Query(queryString);
            Customer customer = null;
            
            try
            {
                while (reader.Read())
                {
                    customer = new Customer()
                    {
                        Id = Convert.ToString(reader["Id"]),
                        FirstName = Convert.ToString(reader["FirstName"]),
                        LastName = Convert.ToString(reader["LastName"]),
                        Street = Convert.ToString(reader["Street"]),
                        City = Convert.ToString(reader["City"]),
                        State = Convert.ToString(reader["State"]),
                        ZIP = Convert.ToString(reader["ZIP"]),
                        Cart = Convert.ToString(reader["Cart"]),
                    };                    
                }
            }
            catch(Exception e)
            {
                // Error Handler
            }

            CloseConnection();

            return customer;
        }

        // Query for Customer given Id, split up Ids of Products in Cart, query for all products, narrow down to products in Cart
        public List<Product> GetCustomerCart(string customerName)
        {
            var customer = GetCustomer(customerName);
            List<string> productIdStrings = customer.Cart.Split('|').ToList();
            List<int> productIds = new List<int>();
            List<int> quantities = new List<int>();
            var customerProducts = new List<Product>();
            int productId;
             
            if(productIdStrings.ElementAt(0) != String.Empty)
            {
                foreach (var id in productIdStrings)
                {
                    var idss = id.Split(',');
                    productId = Convert.ToInt32(idss[0]);
                    productIds.Add(productId);
                }

                var allProducts = GetAllProducts();
                
                Product thisProduct;
                foreach (var id in productIds)
                {
                    thisProduct = (allProducts.Where(x => x.Id == id).FirstOrDefault());

                    if (thisProduct != null)
                        customerProducts.Add(thisProduct);
                }
            }          

            return customerProducts;
        }
        public List<int> GetCustomerQuantities(string customerName)
        {
            var customer = GetCustomer(customerName);
            List<string> productIdStrings = customer.Cart.Split('|').ToList();
            List<int> quantities = new List<int>();

            if (productIdStrings.ElementAt(0) != String.Empty)
            {
                foreach (var id in productIdStrings)
                {
                    var idss = id.Split(',');
                    quantities.Add(Convert.ToInt32(idss[1]));
                }
            }
            return quantities;
        }
            #endregion
        }
}