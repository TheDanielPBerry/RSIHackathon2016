﻿using HackathonRetroStoreWF.Services;
using HackathonRetroStoreWF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace HackathonRetroStoreWF
{
    public partial class AddCustomer : Page
    {
        private readonly DBConnect _db = new DBConnect();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            var firstName = firstNameTB.Text;
            var lastName = lastNameTB.Text;
            var street = streetTB.Text;
            var city = cityTB.Text;
            var state = stateTB.Text;
            var zip = zipTB.Text;

            var customer = new Customer()
            {
                Id = User.Identity.Name,
                FirstName = firstName,
                LastName = lastName,
                Street = street,
                City = city,
                State = state,
                ZIP = zip,
                Cart = String.Empty
            };
            
            var success = _db.CreateCustomer(customer);

            if (success)
                Response.Redirect("~/Default.aspx");
        }
    }
}