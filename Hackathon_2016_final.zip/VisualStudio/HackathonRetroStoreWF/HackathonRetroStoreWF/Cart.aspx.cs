﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HackathonRetroStoreWF.Services;
using HackathonRetroStoreWF.Models;

namespace HackathonRetroStoreWF
{
    public partial class Cart : Page
    {
        private DBConnect _db = new DBConnect();
        protected Customer Customer;
        protected List<Product> CustomerCart;
        protected decimal Total;
        protected string DisplayName;

        protected void Page_Load(object sender, EventArgs e)
        {
            var customerName = User.Identity.Name;
            if (!String.IsNullOrWhiteSpace(customerName))
            {
                Customer = _db.GetCustomer(customerName);
                CustomerCart = _db.GetCustomerCart(customerName);

                if (Customer.FirstName != String.Empty && Customer.LastName != String.Empty)
                {
                    DisplayName = Customer.FirstName + " " + Customer.LastName;
                }
                else
                {
                    DisplayName = Customer.Id;
                }

                Total = CustomerCart.Select(x => x.Price).ToList().Sum();
                Total += (Total % 128);
            }
        }
    }
}