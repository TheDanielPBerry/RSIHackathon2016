﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HackathonRetroStoreWF.Services;
using HackathonRetroStoreWF.Models;
namespace HackathonRetroStoreWF
{
    public partial class ProductDetail : Page
    {
        private DBConnect _db = new DBConnect();
        protected Product Product;
        protected bool IsAuthenticated;

        protected void Page_Load(object sender, EventArgs e)
        {            
            var productId = Convert.ToInt32(Request.QueryString["ProductId"]);
            Product = _db.GetAllProducts().Where(x => x.Id == productId).FirstOrDefault();
            IsAuthenticated = !String.IsNullOrWhiteSpace(User.Identity.Name);

            productPicture.Src = String.Format("~/ProductImages/{0}", Product.PictureFileName);
            hiddenProductId.Value = Convert.ToString(productId);
        }

        protected void ButtonAddToCart_Click(object sender, CommandEventArgs e)
        {
            var prodId = Convert.ToInt32(hiddenProductId.Value);
            var customerName = User.Identity.Name;

            var success = _db.AddToCart(customerName, prodId);

            if (success)
                Response.Redirect("Cart.aspx");          
        }        
    }
}