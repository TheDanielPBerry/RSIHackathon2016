﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HackathonRetroStoreWF.Models
{
    public class Customer
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZIP { get; set; }
        public string Cart { get; set; }
    }
}