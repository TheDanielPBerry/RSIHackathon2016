﻿using HackathonRetroStoreWF.Services;
using HackathonRetroStoreWF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace HackathonRetroStoreWF
{
    public partial class AddProduct : Page
    {
        private readonly DBConnect _db = new DBConnect();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            var name = productNameTB.Text;
            var description = descriptionTB.Text;
            var quantity = quantityTB.Text;
            var price = priceTB.Text;
            var picture = pictureUpload.PostedFile != null ? pictureUpload.PostedFile : null;          
            
           
            if (picture != null && picture.ContentLength > 0)
            {
                var fileName = Path.GetFileName(picture.FileName);
                var path = Path.Combine(Server.MapPath("~/ProductImages/"), fileName);
                picture.SaveAs(path);
            }

            var product = new Product()
            {
                Name = name,
                Description = description,
                QuantityInStock = Convert.ToInt32(quantity),
                Price = Convert.ToDecimal(price),
                PictureFileName = picture.FileName
            };

            var success = _db.SaveNewProduct(product);

            if (success)
                Response.Redirect("~/Store.aspx");
        }
    }
}