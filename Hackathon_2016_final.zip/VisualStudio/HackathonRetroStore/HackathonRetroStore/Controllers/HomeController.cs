﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HackathonRetroStore.Services;

namespace HackathonRetroStore.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            // Renders Views/Home/Index.cshtml
            return View();
        }

        public ActionResult Store()
        {
            // Call Index method in Store controller
            return RedirectToAction("Index", "Store");
        }

        public ActionResult Cart()
        {
            // Call CartView method in Store controller
            var user = User.Identity.Name;
            
            return RedirectToAction("CartView", "Store", new { @customerName = user });
        }
    }
}