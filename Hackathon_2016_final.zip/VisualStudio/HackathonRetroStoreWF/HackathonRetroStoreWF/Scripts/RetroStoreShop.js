﻿$(document).ready(function () {
    $('#MainContent_ProductsGrid').append($('#MainContent_ProductsGrid').find('tr').last().clone());
});