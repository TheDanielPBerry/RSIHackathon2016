﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HackathonRetroStore.Services;
using HackathonRetroStore.Models;
using System.IO;

namespace HackathonRetroStore.Controllers
{
    public class StoreController : Controller
    {
        private readonly DBConnect _db;

        public StoreController()
        {
            _db = new DBConnect();
        }

        // Load Views/Store/Index.cshtml, passing list of Products as model
        public ActionResult Index(String q, int? offset, int? size)
        {
            var products = _db.GetAllProducts();
            ViewData["query"] = q;
            if(!String.IsNullOrWhiteSpace(q))
            {
                products = products.Where<Product>(m => (m.Name.ToUpper().Contains(q.ToUpper()) || m.Description.ToUpper().Contains(q.ToUpper()))).ToList<Product>();
            }
            int off = 0, S = 10;
            if(offset.HasValue)
            {
                if(offset.Value<products.Count())
                {
                    off = offset.Value;
                }else
                {
                    off = products.Count()-size.Value;
                }
            }

            if (size.HasValue)
            {
                if ((offset.Value+size.Value) > products.Count())
                {
                    S = products.Count() - off;
                }
            }
            products = products.Skip(off).Take(S).ToList();
            return View(products);
        }
       
        // Return detail view of a Product, containing a button to add to Cart
        public ActionResult Product(int productId)
        {
            var product = _db.GetAllProducts().Where(x => x.Id == productId).FirstOrDefault();
            return View(product);
        }        

        public ActionResult AddNewProductView()
        {
            return View("~/Views/Store/AddProductForm.cshtml");
        }

        [HttpPost]
        /* Obtain (optional) picture file from request Scripts/RetroStoreShop.js
         * Create model instance of Product, obtaining properties from request
         * On success, call Index method in Store controller */
        public string AddNewProduct()
        {
            var fileName = String.Empty;

            if(Request.Files.Count > 0)
            {
                var file = Request.Files[0];
                if (file != null && file.ContentLength > 0)
                {
                    fileName = Path.GetFileName(file.FileName);
                    var path = Path.Combine(Server.MapPath("~/ProductImages/"), fileName);
                    file.SaveAs(path);
                }
            }

            var formFields = Request.Form;

            Product newProduct = new Product();
            
            newProduct.Name = formFields["productName"];
            newProduct.Description = formFields["description"];
            newProduct.QuantityInStock = Convert.ToInt32(formFields["quantity"]);
            newProduct.Price = Convert.ToDecimal(formFields["price"]);
            newProduct.PictureFileName = fileName;

            var success = _db.SaveNewProduct(newProduct);

            if (success)            
                return Url.Action("Index", "Store");                      
            else
                return String.Empty;
        }

        // Add Product to user's cart. On success, call CartView method in this controller, passing parameter customerName
        public ActionResult AddToCart(int productId, int quantity)
        {
            var customerName = User.Identity.Name;


            var success = _db.AddToCart(customerName, productId, quantity);
            if (success)
                return RedirectToAction("CartView", "Store", new { @customerName = customerName });
            else
                return null;
        }

        // Build ViewModel to relate a customer to his or her Products, and load customer's cart
        public ActionResult CartView(string customerName)
        {            
            var vm = new CustomerCartViewModel();

            if(!String.IsNullOrWhiteSpace(customerName))
            {
                var customer = _db.GetCustomer(customerName);
                var customerCart = _db.GetCustomerCart(customerName);

                vm.Customer = customer;
                vm.Products = customerCart;
                vm.Quantities = _db.GetCustomerQuantities(customerName);
            }

            return View("~/Views/Store/Cart.cshtml", vm);
        }
        
    }
}