﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HackathonRetroStore.Services;
using HackathonRetroStore.Models;

namespace HackathonRetroStore.Controllers
{
    public class CustomerController : Controller
    {
        private readonly DBConnect _db;

        public CustomerController()
        {
            _db = new DBConnect();
        }

        // Load Add Customer page, called after successful Registration
        public ActionResult CreateCustomerView()
        {
            return View("~/Views/Customer/AddCustomer.cshtml");
        }

        // Add customer to Customer DB table. On success, return url redirect string to caller ajax post in Views/Customer/AddCustomer.cshtml
        public string CreateCustomer(string firstName, string lastName, string street, string city, string state, string zip)
        {
            var customer = new Customer()
            {
                Id = User.Identity.Name,
                FirstName = firstName,
                LastName = lastName,
                Street = street,
                City = city,
                State = state,
                ZIP = zip,
                Cart = String.Empty
            };

            var success = _db.CreateCustomer(customer);

            return success ? Url.Action("Index", "Home") : String.Empty;
        }
    }
}