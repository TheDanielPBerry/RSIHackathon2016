﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(HackathonRetroStoreWF.Startup))]
namespace HackathonRetroStoreWF
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
