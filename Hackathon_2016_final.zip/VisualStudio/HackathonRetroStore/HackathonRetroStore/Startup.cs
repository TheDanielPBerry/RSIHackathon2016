﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(HackathonRetroStore.Startup))]
namespace HackathonRetroStore
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
